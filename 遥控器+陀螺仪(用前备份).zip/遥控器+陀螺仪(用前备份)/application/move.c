#include "move.h"
#include "struct_typedef.h"
#include "tim.h"
#include "usart.h"
#include "dbus_task.h"

void move_task_entry(void const * argument)
{
	
	while(1)
	{
		osDelay(10);
	}
}
