#include "gimbal_task.h"
fp32 set_angle =0;
void gimbal_task(void const * argument)
{
	
	
  while(1)
  {			
	    osDelay(1);
  }
}


