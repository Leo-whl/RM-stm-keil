/*
2024.9.19
*/

#include "chassis.h"
#include "dbus_task.h"
#include "math.h"



chassis_control_t chassis_control;
const fp32 speed_pid[3] = {SPEED_PID_KP,SPEED_PID_KI,SPEED_PID_KD};	
const fp32 angle_pid[3]    = {ANGLE_PID_KP,ANGLE_PID_KI,ANGLE_PID_KD};
const fp32 position_pid[3] = {POSITION_PID_KP,POSITION_PID_KI,POSITION_PID_KD};


void chassis_init(void)
{
	chassis_control.speed0_set = 500;
	chassis_control.speed1_set = 500;
	chassis_control.angle0_ecd_set = ANGLE0_INIT_SET;
	chassis_control.angle1_ecd_set = ANGLE1_INIT_SET;
	
	chassis_control.chassis_move_data = get_move_data_point();
	
	chassis_control.angle0_measure = get_motor_point(4);
	chassis_control.angle1_measure = get_motor_point(5);
	chassis_control.speed0_measure = get_motor_point(6);
	chassis_control.speed1_measure = get_motor_point(7);

	PID_init(&chassis_control.speed0_pid,PID_POSITION,speed_pid,SPEED_PID_MAXOUT,SPEED_PID_MAXIOUT);
	PID_init(&chassis_control.speed1_pid,PID_POSITION,speed_pid,SPEED_PID_MAXOUT,SPEED_PID_MAXIOUT);
	PID_init(&chassis_control.angle0_pid,PID_POSITION,angle_pid,ANGLE_PID_MAXOUT,ANGLE_PID_MAXIOUT);
	PID_init(&chassis_control.angle1_pid,PID_POSITION,angle_pid,ANGLE_PID_MAXOUT,ANGLE_PID_MAXIOUT);
	PID_init(&chassis_control.position_angle0_pid,PID_POSITION,position_pid,POSITION_PID_MAXOUT,POSITION_PID_MAXIOUT);
	PID_init(&chassis_control.position_angle1_pid,PID_POSITION,position_pid,POSITION_PID_MAXOUT,POSITION_PID_MAXIOUT);
	
}

//void move_data_upload(void)
//{
//	double err_angle = atan(((double )(chassis_control.chassis_move_data->vx))/((double)(chassis_control.chassis_move_data->vy)))*57.3f;
//	if((chassis_control.chassis_move_data->vx != 0) && (chassis_control.chassis_move_data->vy != 0))
//	{
//		if((chassis_control.chassis_move_data->vx > 0) && (chassis_control.chassis_move_data->vy > 0))
//		{
//		chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + err_angle*22.75f;
//		chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + err_angle*22.75f;
//		}
//		else if((chassis_control.chassis_move_data->vx < 0) && (chassis_control.chassis_move_data->vy > 0))
//		{
//		chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + err_angle*22.75f;
//		chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + err_angle*22.75f;
//		}
//		else if((chassis_control.chassis_move_data->vx < 0) && (chassis_control.chassis_move_data->vy < 0))
//		{
//			if(ANGLE0_INIT_SET + (err_angle-180.0f)*22.75f < 0)
//			{
//				chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + (err_angle-180.0f)*22.75f + 8191.0f;
//				chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + (err_angle-180.0f)*22.75f + 8191.0f;			
//			}
//			else if(ANGLE0_INIT_SET + (err_angle-180.0f)*22.75f >8191)
//			{
//				chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + (err_angle-180.0f)*22.75f - 8191.0f;
//				chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + (err_angle-180.0f)*22.75f - 8191.0f;		
//			}
//		}
//		else if((chassis_control.chassis_move_data->vx > 0) && (chassis_control.chassis_move_data->vy < 0))
//		{
//			if(ANGLE0_INIT_SET + (err_angle-180.0f)*22.75f < 0)
//			{
//				chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + (err_angle+180.0f)*22.75f + 8191.0f;
//				chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + (err_angle+180.0f)*22.75f + 8191.0f;			
//			}
//			else if(ANGLE0_INIT_SET + (err_angle-180.0f)*22.75f >8191)
//			{
//				chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + (err_angle+180.0f)*22.75f - 8191.0f;
//				chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + (err_angle+180.0f)*22.75f - 8191.0f;		
//			}
//		}
//	}
//	else if((chassis_control.chassis_move_data->vx != 0) && (chassis_control.chassis_move_data->vy == 0))
//	{
//		chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + 8191/4.0f;
//		chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + 8191/4.0f;
//		if(chassis_control.angle0_ecd_set > 8191)
//		{
//			chassis_control.angle0_ecd_set -= 8191;
//		}
//		if(chassis_control.angle1_ecd_set > 8191)
//		{
//			chassis_control.angle1_ecd_set -= 8191;
//		}
//	}
//	else if(chassis_control.chassis_move_data->vx == 0)
//	{
//		chassis_control.angle0_ecd_set = ANGLE0_INIT_SET;
//		chassis_control.angle1_ecd_set = ANGLE1_INIT_SET;
//	}

//}
void move_data_upload(void)
{
	double err_angle = atan(((double )(chassis_control.chassis_move_data->vx))/((double)(chassis_control.chassis_move_data->vy)))*57.3f;
	if(chassis_control.chassis_move_data->vx == 0)
	{
		chassis_control.angle0_ecd_set = ANGLE0_INIT_SET;
		chassis_control.angle1_ecd_set = ANGLE1_INIT_SET;
	}
	else
	{
		if(chassis_control.chassis_move_data->vy == 0)
		{
			chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + 8191/4.0f;
			chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + 8191/4.0f;
			if(chassis_control.angle0_ecd_set > 8191)
			{
				chassis_control.angle0_ecd_set -= 8191;
			}
			if(chassis_control.angle1_ecd_set > 8191)
			{
				chassis_control.angle1_ecd_set -= 8191;
			}
		}
		else
		{
			int panduan = signbit(chassis_control.chassis_move_data->vy);
			if(panduan == 0)
			{
				chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + err_angle*22.75f;
				chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + err_angle*22.75f;
			}
			else
			{
			double vvx =-chassis_control.chassis_move_data->vx;
			double err_err_angle = atan(((double )vvx)/((double)(chassis_control.chassis_move_data->vy)))*57.3f;
				chassis_control.angle0_ecd_set = ANGLE0_INIT_SET + err_err_angle*22.75f;
				chassis_control.angle1_ecd_set = ANGLE1_INIT_SET + err_err_angle*22.75f;
			}
		}
		
	}

}

void speed_data_upload(void)
{
	if(chassis_control.chassis_move_data->vx == 0)
	{
		chassis_control.speed0_set = chassis_control.chassis_move_data->vy;
		chassis_control.speed1_set = chassis_control.chassis_move_data->vy;
	}
	else
	{
		if(chassis_control.chassis_move_data->vy == 0)
		{
			chassis_control.speed0_set = chassis_control.chassis_move_data->vx;
			chassis_control.speed1_set = chassis_control.chassis_move_data->vx;
			
		}
		else
		{
			double changdu = sqrt(pow(chassis_control.chassis_move_data->vy,2.0)+pow(chassis_control.chassis_move_data->vx,2.0));
			double bizhi = chassis_control.chassis_move_data->vy/changdu;
			double max_changdu = bizhi*10000.0f;
				chassis_control.speed0_set =changdu/max_changdu*10000.0f;
				chassis_control.speed1_set =changdu/max_changdu*10000.0f;
				if(chassis_control.speed0_set>8191.0f)
				{
					chassis_control.speed0_set = 8191.0f;
				}
				if(chassis_control.speed0_set<-8191.0f)
				{
					chassis_control.speed0_set = -8191.0f;
				}
				if(chassis_control.speed1_set>8191.0f)
				{
					chassis_control.speed1_set = 8191.0f;
				}
				if(chassis_control.speed1_set<-8191.0f)
				{
					chassis_control.speed1_set = -8191.0f;
				}
		}
	}

}

void chassis_task_loop(void)
{
	move_data_upload();
	speed_data_upload();
	PID_calc(&chassis_control.speed0_pid,chassis_control.speed0_measure->speed_rpm,chassis_control.speed0_set);
	PID_calc(&chassis_control.speed1_pid,chassis_control.speed1_measure->speed_rpm,chassis_control.speed1_set);
	PID_calc(&chassis_control.position_angle0_pid,chassis_control.angle0_measure->ecd,chassis_control.angle0_ecd_set);
	PID_calc(&chassis_control.angle0_pid,chassis_control.angle0_measure->speed_rpm,chassis_control.position_angle0_pid.out);
	PID_calc(&chassis_control.position_angle1_pid,chassis_control.angle1_measure->ecd,chassis_control.angle1_ecd_set);
	PID_calc(&chassis_control.angle1_pid,chassis_control.angle1_measure->speed_rpm,chassis_control.position_angle1_pid.out);
	CAN_cmd_gimbal(chassis_control.angle0_pid.out,chassis_control.angle1_pid.out,chassis_control.speed0_pid.out,chassis_control.speed1_pid.out);
	
}
	
void chassis_task_entry(void *argument)
{
	can_filter_init();		
	chassis_init();
	
  for(;;)
  {
		chassis_task_loop();
		osDelay(1);
  }
  /* USER CODE END chassis_task_entry */
}
