#include "move.h"
#include "struct_typedef.h"
#include "tim.h"
#include "usart.h"

void move_task_entry(void const * argument)
{

	while(1)
	{

		osDelay(10);
	}
}
