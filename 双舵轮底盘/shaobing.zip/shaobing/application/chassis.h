#ifndef __CHASSIS_H
#define __CHASSIS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "CAN_receive.h"
#include "bsp_can.h"
#include "pid.h"
#include "dbus_task.h"


#define DEAD_ILNE 300

#define MAX_SPEED 16000
//3508�ٶȻ�PID
#define SPEED_PID_KP 								5.0f
#define SPEED_PID_KI 								0.0f
#define SPEED_PID_KD 								0.0f
#define SPEED_PID_MAXOUT  					16000.0f
#define SPEED_PID_MAXIOUT 					2000.0f
//6020�ٶȻ�PID
#define ANGLE_PID_KP 								50.0f
#define ANGLE_PID_KI 								0.0f
#define ANGLE_PID_KD 								0.0f
#define ANGLE_PID_MAXOUT  					30000.0f
#define ANGLE_PID_MAXIOUT 					2000.0f
//6020�ǶȻ�PID
#define POSITION_PID_KP							0.5f
#define POSITION_PID_KI							0.0f
#define POSITION_PID_KD							0.0f
#define POSITION_PID_MAXOUT 				800.0f
#define POSITION_PID_MAXIOUT 				20.0f

#define ANGLE0_INIT_SET   4096
#define ANGLE1_INIT_SET   4096
typedef struct
{

	const move_data *chassis_move_data;
	
	const motor_measure_t *angle0_measure;
	const motor_measure_t *angle1_measure;
	const motor_measure_t *speed0_measure;
	const motor_measure_t *speed1_measure;

	pid_type_def angle0_pid;
	pid_type_def position_angle0_pid;
	pid_type_def angle1_pid;
	pid_type_def position_angle1_pid;
	pid_type_def speed0_pid;
	pid_type_def speed1_pid;

	uint16_t angle0_ecd_set;
	uint16_t angle1_ecd_set;
	int32_t  angle0_set;
	int32_t  angle1_set;
	
	int32_t speed0_set;
	int32_t speed1_set;
	
	
} chassis_control_t;

void chassis_task_entry(void *argument);

	
#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
