/*
	2024/11/7
	wzq
*/

#include "gimbal_task.h"

void gimbal_task(void const * argument)
{
	

	
  while(1)
  {			
	    osDelay(1);
  }
}


